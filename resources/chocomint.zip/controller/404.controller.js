sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("chocomint.controller.404",{onInit(){}})});
//# sourceMappingURL=404.controller.js.map