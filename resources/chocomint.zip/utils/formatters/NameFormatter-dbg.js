sap.ui.define([], function () {
    "use strict";

    return {
        fullname: (firstName, lastName) => {
            return `${firstName} ${lastName}`;
        },
    };
});
