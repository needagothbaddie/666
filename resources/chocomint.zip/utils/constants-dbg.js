sap.ui.define([], function () {
    "use strict";

    return {
        EMPLOYEE_FORM: "EmplCreate",
        EMPLOYEE_LIST: "EmplList",
        EMPLOYEE_INFO: "EmplDetail",
        DEPT_LIST: "DeptList",
        ROLE_LIST: "RoleList",
    };
});
