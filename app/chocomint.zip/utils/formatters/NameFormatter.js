sap.ui.define([],function(){"use strict";return{fullname:(e,n)=>`${e} ${n}`}});
//# sourceMappingURL=NameFormatter.js.map